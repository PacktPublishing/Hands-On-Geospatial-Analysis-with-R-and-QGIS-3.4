## Section 6,Extending Beyond the Map

## package installation
# install.packages(c("rcartocolor", "sf", "ggplot2", "spData", "dplyr"))

library(rcartocolor) # palette
library(sf)
library(spData) # map of the world
library(ggplot2)
library(dplyr) # data analysis

## Video 2, Novel Ways of Mapping Making - Creating a Dot Map ####
## create a gridded dot map for the Vancouver 2016 population

## reading in Vancouver census shapefile
van <- st_read("../spatial_files/vancouver.shp")

## selecting columns for the dot map
van <- van %>% 
  select(popn, geometry)

## creating equal interval grids 
van_grid <- st_make_grid(van, n = 50)

## area weighted interpolation
van_dot_map <- van %>% 
  st_interpolate_aw(to = van_grid, extensive = FALSE) %>% 
  st_centroid()

## plotting
ggplot() +
  geom_sf(data = van_dot_map, aes(size = popn), alpha = 0.7, 
          show.legend = "point", colour = "grey20") +
  labs(title = "Interpolated Vancouver Population in 2016") +
  scale_size_area(name = "", max_size = 6) +
  theme_void() +
  theme(panel.grid = element_line(colour = "transparent"), 
        plot.title = element_text(hjust = 0.5, margin = margin(10, 0, 0, 0)),
        text = element_text(size = 14))
  

## Video 3, Data Types and Colour Choices ####

## displaying all colour palette options from rcartocolor package
display_carto_all()

## plotting categorical values
ggplot(world, aes(fill = continent)) +
  geom_sf(data = world) +
  coord_sf(crs = "+proj=robin") +
  scale_fill_carto_d() +
  theme_void()

## plotting continuous values
ggplot(world, aes(fill = lifeExp)) +
  geom_sf(data = world) +
  coord_sf(crs = "+proj=robin") +
  scale_fill_carto_c(name = "Life Expectancy", 
                     palette = "BrwnYl") +
  theme_void()


## Video 5, OpenStreetMaps and Further Resources ####

install.packages("devtools")
devtools::install_github("dkahle/ggmap")
library(ggmap)
library(dplyr)

## querying for Stamen Watercolor tile for a defined area
get_stamenmap(bbox = c(left = -123.3, bottom = 49, right = -122.5, top = 49.5), 
              maptype = "watercolor") %>% 
  ggmap()

## creating the watercolor map object
watercolor_map <- get_stamenmap(bbox = c(left = -123.3, bottom = 49, right = -122.5, top = 49.5), 
              maptype = "watercolor") 

## plotting with ggplot 
ggmap(watercolor_map) +
  geom_point(aes(x = -123, y = 49.3), colour = "red", size = 3)
